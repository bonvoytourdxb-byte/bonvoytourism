import React from 'react'

import ContactUsCTR from '@/containers/contact-us/ContactUsCTR'

function page() {
    return (
        <>
            <ContactUsCTR />
        </>
    )
}

export default page
