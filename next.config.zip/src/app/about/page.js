import React from 'react'

import AboutCTR from '@/containers/about/AboutCTR'

function page() {
    return (
        <>
            <AboutCTR />
        </>
    )
}

export default page
