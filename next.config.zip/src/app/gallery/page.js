import React from 'react'

import GalleryCTR from '@/containers/gallery/GalleryCTR'

function page() {
    return (
        <>
            <GalleryCTR />
        </>
    )
}

export default page
