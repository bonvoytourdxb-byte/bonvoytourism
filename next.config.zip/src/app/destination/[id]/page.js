"use client";

import React from 'react'

import DetailCTR from '@/containers/destination/detail/DetailCTR'

function page() {
    return (
        <>
            <DetailCTR />
        </>
    )
}

export default page
